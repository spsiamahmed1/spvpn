package com.sp.spvpn;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import ai.bongotech.bongovpn.BongoVpn;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_PICK = 4001;
    private static final int MAX_FILE = 512 * 1024;
    private static final String PREFS = "spvpn_prefs";

    private static final int OFF = 0;
    private static final int CONNECTING = 1;
    private static final int ON = 2;

    private static final class Profile {
        final String name;
        final String content;

        Profile(String name, String content) {
            this.name = name;
            this.content = content;
        }
    }

    private BongoVpn bongoVpn;
    private TextView btnConnect;
    private TextView tvStatus;
    private TextView tvDetail;
    private TextView tvTimer;
    private TextView tvDown;
    private TextView tvUp;
    private TextView tvDownTotal;
    private TextView tvUpTotal;
    private TextView tvNoServer;
    private View serverRow;
    private Spinner spServers;
    private EditText etUser;
    private EditText etPass;

    private final List<Profile> profiles = new ArrayList<>();
    private int state = OFF;
    private boolean pendingConnect = false;
    private long connectedAt = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (state == ON) {
                long s = (SystemClock.elapsedRealtime() - connectedAt) / 1000;
                tvTimer.setText(String.format(Locale.US, "%02d:%02d:%02d",
                        s / 3600, (s % 3600) / 60, s % 60));
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setContentView(R.layout.activity_main);

        btnConnect = findViewById(R.id.btnConnect);
        tvStatus = findViewById(R.id.tvStatus);
        tvDetail = findViewById(R.id.tvDetail);
        tvTimer = findViewById(R.id.tvTimer);
        tvDown = findViewById(R.id.tvDown);
        tvUp = findViewById(R.id.tvUp);
        tvDownTotal = findViewById(R.id.tvDownTotal);
        tvUpTotal = findViewById(R.id.tvUpTotal);
        tvNoServer = findViewById(R.id.tvNoServer);
        serverRow = findViewById(R.id.serverRow);
        spServers = findViewById(R.id.spServers);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);

        etUser.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("user", ""));
        loadProfiles();
        refreshServers(getSharedPreferences(PREFS, MODE_PRIVATE).getInt("selected", 0));

        bongoVpn = new BongoVpn(this);
        if (!bongoVpn.hasNotificationPermission()) {
            bongoVpn.requestNotificationPermission();
        }
        bongoVpn.setVpnListener(new BongoVpn.VpnListener() {
            @Override
            public void onVpnConnected() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        connectedAt = SystemClock.elapsedRealtime();
                        setState(ON);
                        handler.post(ticker);
                    }
                });
            }

            @Override
            public void onVpnStopped() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setState(OFF);
                    }
                });
            }

            @Override
            public void onStatusUpdate(final String status) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvDetail.setText(status);
                    }
                });
            }

            @Override
            public void onError(final String errorMessage) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setState(OFF);
                        tvDetail.setText(getString(R.string.err_prefix, errorMessage));
                    }
                });
            }

            @Override
            public void onSpeedUpdate(final long downloadBytes, final long uploadBytes,
                                      final long downloadSpeed, final long uploadSpeed) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvDown.setText(bongoVpn.formatSpeed(downloadSpeed));
                        tvUp.setText(bongoVpn.formatSpeed(uploadSpeed));
                        tvDownTotal.setText(bongoVpn.formatBytes(downloadBytes));
                        tvUpTotal.setText(bongoVpn.formatBytes(uploadBytes));
                    }
                });
            }
        });

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onConnectClicked();
            }
        });
        ((Button) findViewById(R.id.btnAdd)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickFile();
            }
        });
        ((Button) findViewById(R.id.btnDelete)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });
        spServers.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View view, int pos, long id) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("selected", pos).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });

        setState(OFF);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // VPN অনুমতির ডায়ালগ থেকে ফিরে এলে সংযোগ শুরু করি
        if (pendingConnect) {
            pendingConnect = false;
            if (bongoVpn.hasVpnPermission()) {
                setState(CONNECTING);
                bongoVpn.startVpn();
            }
        }
    }

    private void onConnectClicked() {
        if (state != OFF) {
            bongoVpn.stopVpn();
            setState(OFF);
            return;
        }
        if (profiles.isEmpty()) {
            Toast.makeText(this, R.string.toast_need_server, Toast.LENGTH_SHORT).show();
            return;
        }
        int pos = Math.max(0, spServers.getSelectedItemPosition());
        Profile p = profiles.get(pos);
        String user = etUser.getText().toString().trim();
        String pass = etPass.getText().toString();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("user", user).apply();
        try {
            bongoVpn.attachFromString(p.content, user, pass);
        } catch (Exception e) {
            tvDetail.setText(getString(R.string.err_prefix, String.valueOf(e.getMessage())));
            return;
        }
        if (bongoVpn.hasVpnPermission()) {
            setState(CONNECTING);
            bongoVpn.startVpn();
        } else {
            pendingConnect = true;
            bongoVpn.requestVpnPermission();
        }
    }

    private void setState(int s) {
        state = s;
        handler.removeCallbacks(ticker);
        switch (s) {
            case CONNECTING:
                btnConnect.setBackgroundResource(R.drawable.bg_btn_connecting);
                btnConnect.setText(R.string.btn_cancel);
                tvStatus.setText(R.string.st_connecting);
                break;
            case ON:
                btnConnect.setBackgroundResource(R.drawable.bg_btn_on);
                btnConnect.setText(R.string.btn_disconnect);
                tvStatus.setText(R.string.st_on);
                break;
            default:
                btnConnect.setBackgroundResource(R.drawable.bg_btn_off);
                btnConnect.setText(R.string.btn_connect);
                tvStatus.setText(R.string.st_off);
                tvTimer.setText("00:00:00");
                tvDown.setText("0 B/s");
                tvUp.setText("0 B/s");
                tvDownTotal.setText("0 B");
                tvUpTotal.setText("0 B");
                break;
        }
    }

    // ---------- সার্ভার (.ovpn) তালিকা ----------

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        String text;
        try {
            text = readText(uri);
        } catch (IOException e) {
            Toast.makeText(this, R.string.toast_read_fail, Toast.LENGTH_SHORT).show();
            return;
        }
        if (text == null) {
            Toast.makeText(this, R.string.toast_too_big, Toast.LENGTH_SHORT).show();
            return;
        }
        String lower = text.toLowerCase(Locale.US);
        if (!lower.contains("remote ") && !lower.contains("client")) {
            Toast.makeText(this, R.string.toast_bad_file, Toast.LENGTH_LONG).show();
            return;
        }
        String name = displayName(uri);
        profiles.add(new Profile(name, text));
        saveProfiles();
        refreshServers(profiles.size() - 1);
        Toast.makeText(this, R.string.toast_added, Toast.LENGTH_SHORT).show();
    }

    private String readText(Uri uri) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) {
            throw new IOException("no stream");
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        int total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > MAX_FILE) {
                in.close();
                return null;
            }
            bos.write(buf, 0, n);
        }
        in.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (c.moveToFirst() && idx >= 0) {
                    name = c.getString(idx);
                }
            } finally {
                c.close();
            }
        }
        if (name == null || name.isEmpty()) {
            name = "server-" + (profiles.size() + 1);
        }
        if (name.toLowerCase(Locale.US).endsWith(".ovpn")) {
            name = name.substring(0, name.length() - 5);
        }
        return name;
    }

    private void confirmDelete() {
        if (profiles.isEmpty()) {
            return;
        }
        final int pos = Math.max(0, spServers.getSelectedItemPosition());
        new AlertDialog.Builder(this)
                .setMessage(R.string.confirm_delete)
                .setPositiveButton(R.string.yes_delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        if (pos < profiles.size()) {
                            profiles.remove(pos);
                            saveProfiles();
                            refreshServers(0);
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void refreshServers(int select) {
        boolean has = !profiles.isEmpty();
        serverRow.setVisibility(has ? View.VISIBLE : View.GONE);
        tvNoServer.setVisibility(has ? View.GONE : View.VISIBLE);
        List<String> names = new ArrayList<>();
        for (Profile p : profiles) {
            names.add(p.name);
        }
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, R.layout.spinner_item, names);
        ad.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spServers.setAdapter(ad);
        if (has) {
            spServers.setSelection(Math.max(0, Math.min(select, profiles.size() - 1)));
        }
    }

    private void loadProfiles() {
        profiles.clear();
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(sp.getString("profiles", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                profiles.add(new Profile(o.getString("n"), o.getString("c")));
            }
        } catch (JSONException ignored) {
        }
    }

    private void saveProfiles() {
        JSONArray arr = new JSONArray();
        try {
            for (Profile p : profiles) {
                JSONObject o = new JSONObject();
                o.put("n", p.name);
                o.put("c", p.content);
                arr.put(o);
            }
        } catch (JSONException ignored) {
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("profiles", arr.toString()).apply();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(ticker);
        if (bongoVpn != null) {
            bongoVpn.release();
        }
        super.onDestroy();
    }
}
